@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4>Edit Order</h4>
        </div>

        <div class="card-body">
            <form action="{{ route('orders.update', $order->id) }}" method="POST">
                @csrf
                @method('PUT')

                {{-- Nama Customer --}}
                <div class="mb-3">
                    <label class="form-label">Nama Customer</label>
                    <input type="text" name="customer_name"
                        class="form-control @error('customer_name') is-invalid @enderror"
                        value="{{ old('customer_name', $order->customer_name) }}" required>

                    @error('customer_name')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Nama Produk --}}
                <div class="mb-3">
                    <label class="form-label">Nama Produk</label>
                    <input type="text" name="product_name"
                        class="form-control @error('product_name') is-invalid @enderror"
                        value="{{ old('product_name', $order->product_name) }}" required>

                    @error('product_name')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Jumlah --}}
                <div class="mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="quantity"
                        class="form-control @error('quantity') is-invalid @enderror"
                        value="{{ old('quantity', $order->quantity) }}" required>

                    @error('quantity')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Harga --}}
                <div class="mb-3">
                    <label class="form-label">Harga</label>
                    <input type="number" name="price"
                        class="form-control @error('price') is-invalid @enderror"
                        value="{{ old('price', $order->price) }}" required>

                    @error('price')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Tombol --}}
                <div class="mt-4">
                    <a href="{{ route('orders.index') }}" class="btn btn-secondary">Kembali</a>
                    <button type="submit" class="btn btn-success">Update Order</button>
                </div>

            </form>
        </div>
    </div>
</div>
@endsection