@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto bg-white p-6 shadow rounded">
    <h1 class="text-2xl font-bold mb-4">Tambah Order Baru</h1>

    @if ($errors->any())
    <div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
        <strong>Ada kesalahan!</strong>
        <ul class="mt-2 text-sm">
            @foreach ($errors->all() as $error)
            <li>- {{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <form action="{{ route('orders.store') }}" method="POST">
        @csrf

        <!-- Nama Pelanggan -->
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Nama Pelanggan</label>
            <input type="text" name="nama_pelanggan" required
                class="w-full border rounded px-3 py-2"
                placeholder="Masukkan nama pelanggan">
        </div>

        <!-- Layanan -->
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Layanan</label>
            <select name="layanan" class="w-full border rounded px-3 py-2" required>
                <option value="">-- Pilih Layanan --</option>
                <option value="Cuci Kering">Cuci Kering</option>
                <option value="Cuci Basah">Cuci Basah</option>
                <option value="Setrika">Setrika</option>
                <option value="Cuci + Setrika">Cuci + Setrika</option>
            </select>
        </div>

        <!-- Berat -->
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Berat (kg)</label>
            <input type="number" name="berat" class="w-full border rounded px-3 py-2"
                placeholder="Masukkan berat">
        </div>

        <!-- Total Harga -->
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Total Harga (Rp)</label>
            <input type="number" name="total_harga" required
                class="w-full border rounded px-3 py-2"
                placeholder="Masukkan total harga">
        </div>

        <!-- Status -->
        <div class="mb-4">
            <label class="block mb-1 font-semibold">Tahap Proses</label>
            <select name="process_status" class="w-full border rounded px-3 py-2">
                <option value="penerimaan">Penerimaan</option>
                <option value="pencucian">Pencucian</option>
                <option value="pengeringan">Pengeringan</option>
                <option value="setrika">Setrika</option>
                <option value="selesai">Selesai</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block mb-1 font-semibold">Status</label>
            <select name="status" class="w-full border rounded px-3 py-2" required>
                <option value="proses">Proses</option>
                <option value="selesai">Selesai</option>
                <option value="diambil">Sudah Diambil</option>
            </select>
        </div>

        <!-- Tombol Simpan -->
        <div class="flex justify-end">
            <a href="{{ route('orders.index') }}"
                class="px-4 py-2 bg-gray-300 rounded mr-2">Kembali</a>

            <button type="submit"
                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                Simpan
            </button>
        </div>

    </form>
</div>
@endsection