@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto bg-white p-6 shadow rounded">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-2xl font-bold">Data Order Laundry</h1>

        <a href="{{ route('orders.create') }}"
            class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            + Tambah Order
        </a>
    </div>

    {{-- Alert sukses --}}
    @if(session('success'))
    <div class="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded">
        {{ session('success') }}
    </div>
    @endif

    {{-- Jika tidak ada data --}}
    @if($orders->isEmpty())
    <p class="text-gray-600">Belum ada data order.</p>
    @else
    <div class="overflow-x-auto">
        <table class="w-full border-collapse border border-gray-300">
            <thead class="bg-gray-200">
                <tr>
                    <th class="border px-3 py-2">ID</th>
                    <th class="border px-3 py-2">Nama Pelanggan</th>
                    <th class="border px-3 py-2">Layanan</th>
                    <th class="border px-3 py-2">Berat (kg)</th>
                    <th class="border px-3 py-2">Total Harga</th>
                    <th class="border px-3 py-2">Status</th>
                    <th class="border px-3 py-2" width="160">Aksi</th>
                    <th>Status Proses</th>
                </tr>
            </thead>

            <tbody>
                @foreach($orders as $order)
                <tr>
                    <td class="border px-3 py-2 text-center">{{ $order->id }}</td>
                    <td class="border px-3 py-2">{{ $order->nama_pelanggan }}</td>
                    <td class="border px-3 py-2">{{ $order->layanan }}</td>
                    <td class="border px-3 py-2 text-center">{{ $order->berat ?? '-' }}</td>
                    <td class="border px-3 py-2">Rp {{ number_format($order->total_harga, 0, ',', '.') }}</td>

                    <td class="border px-3 py-2">
                        @if($order->status === 'proses')
                        <span class="px-2 py-1 bg-yellow-200 text-yellow-800 rounded text-sm">
                            Proses
                        </span>
                        @elseif($order->status === 'selesai')
                        <span class="px-2 py-1 bg-green-200 text-green-800 rounded text-sm">
                            Selesai
                        </span>
                        @else
                        <span class="px-2 py-1 bg-blue-200 text-blue-800 rounded text-sm">
                            Diambil
                        </span>
                        @endif
                    </td>
                    <td>{{ ucfirst($order->process_status) }}</td>


                    <td class="border px-3 py-2 text-center">
                        <a href="{{ route('orders.edit', $order->id) }}"
                            class="px-3 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600">
                            Edit
                        </a>

                        <form action="{{ route('orders.destroy', $order->id) }}"
                            method="POST" class="inline-block"
                            onsubmit="return confirm('Yakin ingin menghapus?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                class="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">
                                Hapus
                    <td class="p-3">
                        <a href="{{ route('orders.notify.done', $order->id) }}"
                            class="px-3 py-1 bg-green-600 text-white rounded">
                            Kirim Notifikasi Selesai
                        </a>

                        <a href="{{ route('orders.notify.pickup', $order->id) }}"
                            class="px-3 py-1 bg-blue-600 text-white rounded ml-2">
                            Kirim Estimasi Pengambilan
                        </a>
                    </td>

                    </button>
                    </form>

                    </td>
                </tr>
                @endforeach
            </tbody>

        </table>
    </div>
    @endif
</div>
@endsection