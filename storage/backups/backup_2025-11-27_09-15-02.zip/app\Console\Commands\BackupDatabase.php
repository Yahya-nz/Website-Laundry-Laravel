<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class BackupLaundry extends Command
{
    protected $signature = 'laundry:backup';
    protected $description = 'Backup project dan database website laundry';

    public function handle()
    {
        $date = date('Y-m-d_H-i-s');
        $backupPath = storage_path("backups/backup_$date.zip");
        $dbBackupPath = storage_path("backups/db_$date.sql");

        // === Backup database ===
        $db = env('DB_DATABASE');
        $user = env('DB_USERNAME');
        $pass = env('DB_PASSWORD');
        $host = env('DB_HOST');

        if (!empty($pass)) {
            // Jika password ADA → gunakan -pPASSWORD
            $command = "mysqldump -h $host -u $user -p$pass $db > $dbBackupPath";
        } else {
            // Jika password KOSONG → jangan gunakan -p sama sekali
            $command = "mysqldump -h $host -u $user $db > $dbBackupPath";
        }
        system($command);


        // === Zip project ===
        $projectDir = base_path();
        $zipScript = "
Add-Type -A 'System.IO.Compression.FileSystem';
[IO.Compression.ZipFile]::CreateFromDirectory('$projectDir', '$backupPath');
";
        file_put_contents(storage_path('backups/zip.ps1'), $zipScript);

        system("powershell -ExecutionPolicy Bypass -File " . storage_path('backups/zip.ps1'));


        // Hapus SQL setelah masuk ZIP
        unlink($dbBackupPath);

        $this->info("Backup selesai: $backupPath");
    }
}
