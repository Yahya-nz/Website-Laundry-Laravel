@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto p-6">
    <div class="bg-white shadow-lg rounded-lg p-8">

        <h1 class="text-3xl font-bold text-blue-600 mb-4">Profil Usaha Laundry Ukhuwah</h1>

        <p class="text-gray-700 leading-relaxed mb-4">
            Laundry Ukhuwah adalah jasa laundry terpercaya yang berkomitmen
            memberikan pelayanan terbaik untuk menjaga kebersihan dan kenyamanan pakaian Anda.
        </p>

        <h2 class="text-2xl font-semibold text-blue-600 mt-6 mb-2">Visi</h2>
        <p class="text-gray-700 mb-4">
            Menjadi layanan laundry terbaik dengan pelayanan cepat, bersih, dan profesional.
        </p>

        <h2 class="text-2xl font-semibold text-blue-600 mt-6 mb-2">Misi</h2>
        <ul class="list-disc ml-6 text-gray-700">
            <li>Memberikan layanan laundry berkualitas tinggi.</li>
            <li>Menjaga kebersihan dan kerapian pakaian pelanggan.</li>
            <li>Memberikan harga terjangkau untuk semua kalangan.</li>
            <li>Pelayanan cepat dan tepat waktu.</li>
        </ul>

        <h2 class="text-2xl font-semibold text-blue-600 mt-6 mb-2">Kontak Kami</h2>
        <p class="text-gray-700">
            📞 <b>0812-3456-7890</b><br>
            📍 Alamat: Jl. Mawar No.12, Tegal
        </p>

        <div class="mt-6">
            <a href="{{ route('home') }}"
                class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                Kembali ke Halaman Depan
            </a>
        </div>

    </div>
</div>
@endsection