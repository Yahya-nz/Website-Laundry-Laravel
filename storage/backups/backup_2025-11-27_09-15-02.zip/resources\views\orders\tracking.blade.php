@extends('layouts.app')

@section('content')
<div class="container mt-4">

    <h2 class="mb-4">Tracking Status Cucian</h2>

    <div class="card shadow">
        <div class="card-body">

            <h5><strong>Nama Pelanggan:</strong> {{ $order->nama_pelanggan }}</h5>
            <h5><strong>Layanan:</strong> {{ $order->layanan }}</h5>
            <h5><strong>Berat:</strong> {{ $order->berat }} Kg</h5>
            <h5><strong>Status Proses:</strong> {{ ucfirst($order->process_status) }}</h5>

            <hr>

            <h4 class="mb-3">Progress Pengerjaan:</h4>

            @if($order->notified_done)
            <div class="p-3 bg-green-100 border border-green-400 text-green-800 rounded mb-3">
                Cucian Anda sudah SELESAI! Silakan ambil kapan saja.
            </div>
            @endif

            @if($order->pickup_estimation)
            <div class="p-3 bg-blue-100 border border-blue-400 text-blue-800 rounded mb-3">
                Estimasi waktu pengambilan:
                <strong>{{ \Carbon\Carbon::parse($order->pickup_estimation)->format('d M Y H:i') }}</strong>
            </div>
            @endif


            @php
            // pastikan $progress sudah dikirim dari controller (0..100)
            $width = ($progress ?? 0) . '%';
            @endphp

            <div style="background:#e5e7eb;border-radius:8px;overflow:hidden;height:28px;">
                <div role="progressbar"
                    aria-valuenow="{{ $progress ?? 0 }}"
                    aria-valuemin="0"
                    aria-valuemax="100"
                    style="background: linear-gradient(90deg,#06b6d4,#3b82f6); height:100%; width: <?php echo $width; ?>; color: #fff; display:flex; align-items:center; justify-content:center; font-weight:600;">
                    <?php echo ($progress ?? 0) . '%'; ?>
                </div>
            </div>

            {{-- Optional: step labels --}}
            <div class="mt-4 grid grid-cols-5 gap-2 text-center text-sm">
                <div class="{{ $order->process_status == 'penerimaan' ? 'font-semibold text-blue-700' : 'text-gray-500' }}">Penerimaan</div>
                <div class="{{ $order->process_status == 'pencucian' ? 'font-semibold text-blue-700' : 'text-gray-500' }}">Pencucian</div>
                <div class="{{ $order->process_status == 'pengeringan' ? 'font-semibold text-blue-700' : 'text-gray-500' }}">Pengeringan</div>
                <div class="{{ $order->process_status == 'setrika' ? 'font-semibold text-blue-700' : 'text-gray-500' }}">Setrika</div>
                <div class="{{ $order->process_status == 'selesai' ? 'font-semibold text-blue-700' : 'text-gray-500' }}">Selesai</div>
            </div>

        </div>
    </div>

</div>
@endsection