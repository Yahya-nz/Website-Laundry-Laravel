<x-app-layout>
    <h1 class="text-2xl font-bold">User Dashboard</h1>

    <div class="mt-4">
        <p>Selamat datang pengguna! Ini adalah halaman dashboard Anda.</p>
    </div>
</x-app-layout>