@extends('layouts.app')

@section('content')
<div class="container mt-4">

    <h2 class="mb-4">Tambah Transaksi Laundry</h2>

    @if ($errors->any())
    <div class="alert alert-danger">
        <strong>Periksa kembali input Anda!</strong>
    </div>
    @endif

    <form action="{{ route('transactions.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label class="form-label">Nama Pelanggan</label>
            <input type="text" name="nama_pelanggan" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Layanan</label>
            <select name="layanan" class="form-control" required>
                <option value="Cuci Kering">Cuci Kering</option>
                <option value="Cuci Basah">Cuci Basah</option>
                <option value="Setrika">Setrika</option>
                <option value="Cuci + Setrika">Cuci + Setrika</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Berat (kg)</label>
            <input type="number" name="berat" class="form-control" min="1" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Total Harga (Rp)</label>
            <input type="number" name="total_harga" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Metode Pembayaran</label>
            <select name="metode_pembayaran" class="form-control" required>
                <option value="tunai">Tunai</option>
                <option value="transfer">Transfer Bank</option>
                <option value="ewallet">E-Wallet</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Status Pembayaran</label>
            <select name="status_pembayaran" class="form-control" required>
                <option value="belum_dibayar">Belum Dibayar</option>
                <option value="dibayar">Dibayar</option>
            </select>
        </div>

        <button class="btn btn-success">Simpan Transaksi</button>
        <a href="{{ route('transactions.index') }}" class="btn btn-secondary">Kembali</a>

    </form>
</div>
@endsection