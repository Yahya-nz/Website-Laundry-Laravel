<a href="/">
    <img src="{{ asset('images/laundry-logo.png') }}"
        alt="Laundry Ukhuwah"
        class="h-16 w-auto mx-auto">
</a>