@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto bg-white p-6 shadow rounded">
    <h1 class="text-2xl font-bold mb-4">Layanan Kami</h1>

    <ul class="list-disc ml-6 space-y-2">
        <li>Cuci Kering</li>
        <li>Cuci Setrika</li>
        <li>Setrika Saja</li>
        <li>Laundry Kilat (Express)</li>
        <li>Laundry Sepatu</li>
        <li>Laundry Karpet</li>
    </ul>
</div>
@endsection