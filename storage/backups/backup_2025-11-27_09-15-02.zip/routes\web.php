<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TransactionController;


// Route halaman utama
Route::get('/', [OrderController::class, 'index']);

Route::get('/profil-usaha', function () {
    return view('profil');
})->name('profil');

Route::get('/', function () {
    return view('welcome_laundry');
})->name('home');

Route::get('/layanan', function () {
    return view('layanan');
})->name('layanan');

Route::get('/harga', function () {
    return view('harga');
})->name('harga');

Route::get('/tracking/{id}', [OrderController::class, 'tracking'])->name('orders.tracking');

// Route dashboard Breeze
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// CRUD Orders (hanya bisa diakses jika login)
Route::middleware(['auth'])->group(function () {

    // Read
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');

    // Create
    Route::get('/orders/create', [OrderController::class, 'create'])->name('orders.create');
    Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');

    // Update
    Route::get('/orders/{id}/edit', [OrderController::class, 'edit'])->name('orders.edit');
    Route::put('/orders/{id}', [OrderController::class, 'update'])->name('orders.update');

    // Delete
    Route::delete('/orders/{id}', [OrderController::class, 'destroy'])->name('orders.destroy');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/transactions', [TransactionController::class, 'index'])->name('transactions.index');
    Route::get('/transactions/create', [TransactionController::class, 'create'])->name('transactions.create');
    Route::post('/transactions', [TransactionController::class, 'store'])->name('transactions.store');
});


// Route Profile (standar bawaan breeze)
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/orders/{id}/notify-done', [OrderController::class, 'notifyDone'])
    ->name('orders.notify.done');

Route::get('/orders/{id}/notify-pickup', [OrderController::class, 'notifyPickup'])
    ->name('orders.notify.pickup');

// Dashboard Admin
Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/admin', function () {
        return view('admin.dashboard');
    });

    Route::resource('orders', OrderController::class);
    Route::resource('transactions', TransactionController::class);
});

// Dashboard User
Route::middleware(['auth'])->group(function () {
    Route::get('/user', function () {
        return view('user.dashboard');
    });

    Route::get('/order/tracking/{id}', [OrderController::class, 'tracking']);
});

Route::get('/redirect', function () {
    $user = auth()->user();

    if (!$user) {
        return redirect('/login');
    }

    if ($user->role === 'admin') {
        return redirect('/admin');
    }

    return redirect('/user');
})->middleware('auth');

require __DIR__ . '/auth.php';
