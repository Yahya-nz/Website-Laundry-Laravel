@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto p-6">

    <div class="bg-white shadow-lg rounded-lg p-8">
        <h1 class="text-3xl font-bold text-blue-600 text-center mb-4">
            Selamat Datang di Laundry Ukhuwah
        </h1>

        <p class="text-gray-700 text-center mb-6">
            Layanan laundry cepat, bersih, wangi, dan profesional.
            Siap membantu kebutuhan laundry harian Anda.
        </p>

        <div class="text-center">
            <a href="{{ route('orders.create') }}"
                class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                Buat Pesanan Sekarang
            </a>
        </div>
    </div>

    <div class="bg-white shadow-md rounded-lg p-8 mt-6">
        <h2 class="text-2xl font-semibold mb-4 text-blue-600">Layanan Kami</h2>

        <ul class="list-disc ml-6 text-gray-700 leading-relaxed">
            <li>Laundry Kiloan</li>
            <li>Cuci Setrika</li>
            <li>Cuci Saja</li>
            <li>Setrika Saja</li>
            <li>Laundry Express (Selesai 4 jam)</li>
        </ul>
    </div>

    <div class="bg-white shadow-md rounded-lg p-8 mt-6">
        <h2 class="text-2xl font-semibold mb-4 text-blue-600">Daftar Harga</h2>

        <table class="w-full border border-gray-300 rounded-lg">
            <thead>
                <tr class="bg-blue-100">
                    <th class="p-3 border">Layanan</th>
                    <th class="p-3 border">Harga</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="p-3 border">Laundry Kiloan</td>
                    <td class="p-3 border">Rp 8.000 / kg</td>
                </tr>
                <tr>
                    <td class="p-3 border">Cuci Setrika</td>
                    <td class="p-3 border">Rp 10.000 / kg</td>
                </tr>
                <tr>
                    <td class="p-3 border">Setrika Saja</td>
                    <td class="p-3 border">Rp 6.000 / kg</td>
                </tr>
                <tr>
                    <td class="p-3 border">Laundry Express</td>
                    <td class="p-3 border">Rp 15.000 / kg</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="bg-white shadow-md rounded-lg p-8 mt-6 mb-6">
        <h2 class="text-2xl font-semibold mb-4 text-blue-600">Kontak</h2>

        <p class="text-gray-700">
            Jika membutuhkan bantuan atau ingin bertanya,
            silakan hubungi kami:
        </p>

        <p class="text-xl font-bold text-green-600 mt-3">
            📞 0812-3456-7890
        </p>
    </div>

</div>
@endsection