@extends('layouts.app')

@section('content')
<div class="container mt-4">

    <h2 class="mb-4">Data Transaksi Laundry</h2>

    @if (session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <a href="{{ route('transactions.create') }}" class="btn btn-primary mb-3">
        + Tambah Transaksi
    </a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Pelanggan</th>
                <th>Layanan</th>
                <th>Berat (kg)</th>
                <th>Total</th>
                <th>Metode</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($transactions as $t)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $t->nama_pelanggan }}</td>
                <td>{{ $t->layanan }}</td>
                <td>{{ $t->berat }}</td>
                <td>Rp {{ number_format($t->total_harga, 0, ',', '.') }}</td>
                <td>{{ ucfirst($t->metode_pembayaran) }}</td>
                <td>
                    <span class="badge bg-{{ $t->status_pembayaran == 'dibayar' ? 'success' : 'danger' }}">
                        {{ ucfirst(str_replace('_', ' ', $t->status_pembayaran)) }}
                    </span>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" class="text-center">Belum ada transaksi.</td>
            </tr>
            @endforelse
        </tbody>
    </table>

</div>
@endsection