@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto bg-white p-6 shadow rounded">
    <h1 class="text-2xl font-bold mb-4">Daftar Harga Laundry</h1>

    <table class="w-full border">
        <tr class="bg-gray-100">
            <th class="p-2 border">Layanan</th>
            <th class="p-2 border">Harga</th>
        </tr>

        <tr>
            <td class="p-2 border">Cuci Kering</td>
            <td class="p-2 border">Rp 5.000 / kg</td>
        </tr>

        <tr>
            <td class="p-2 border">Cuci Setrika</td>
            <td class="p-2 border">Rp 7.000 / kg</td>
        </tr>

        <tr>
            <td class="p-2 border">Setrika Saja</td>
            <td class="p-2 border">Rp 4.000 / kg</td>
        </tr>

        <tr>
            <td class="p-2 border">Laundry Kilat</td>
            <td class="p-2 border">Rp 10.000 / kg</td>
        </tr>

        <tr>
            <td class="p-2 border">Laundry Sepatu</td>
            <td class="p-2 border">Rp 25.000 / pasang</td>
        </tr>

        <tr>
            <td class="p-2 border">Laundry Karpet</td>
            <td class="p-2 border">Rp 15.000 / m²</td>
        </tr>
    </table>
</div>
@endsection